import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, Star, Truck } from 'lucide-react';
import { fornecedores, produtos } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';

// ============================================
// FornecedorDetalhe — ficha do fornecedor com
// produtos fornecidos e histórico de compras.
// ============================================

const STATUS = { pendente: 'slate', enviado: 'sky', 'em trânsito': 'amber', recebido: 'teal' };
const STATUS_LABEL = { pendente: 'Pendente', enviado: 'Enviado', 'em trânsito': 'Em trânsito', recebido: 'Recebido' };
const PRODUTO_STATUS = { ativo: 'teal', baixo: 'amber', critico: 'red', esgotado: 'slate' };

const BRL = v => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export function FornecedorDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { ordens } = useApp();

  const fornecedor = fornecedores.find(f => f.id === Number(id));
  const fornecidos = produtos.filter(p => p.fornecedor === fornecedor?.nome);
  const historico = ordens.filter(o => o.fornecedor === fornecedor?.nome);
  const totalComprado = historico.reduce((a, o) => a + o.total, 0);
  const recebidos = historico.filter(o => o.status === 'recebido').length;

  if (!fornecedor) {
    return (
      <div className="space-y-6">
        <Button variant="secondary" onClick={() => navigate('/fornecedores')}>
          <ArrowLeft className="h-4 w-4" /> Voltar
        </Button>
        <Card>
          <EmptyState title="Fornecedor não encontrado" description="Volte para a lista de fornecedores." />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div>
        <button
          type="button"
          onClick={() => navigate('/fornecedores')}
          className="flex items-center gap-1 text-sm text-slate-500 transition-colors hover:text-slate-700 dark:hover:text-slate-300"
        >
          <ArrowLeft className="h-4 w-4" /> Voltar para fornecedores
        </button>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-primary-700 text-lg font-semibold text-white">
            {fornecedor.nome.charAt(0)}
          </div>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-800 dark:text-slate-100">{fornecedor.nome}</h1>
            <Badge variant="slate" className="mt-1">{fornecedor.categoria}</Badge>
          </div>
        </div>
      </div>

      {/* Contato + métricas */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Contato</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
              <Mail className="h-4 w-4 text-slate-400" /> {fornecedor.contato}
            </p>
            <p className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
              <Phone className="h-4 w-4 text-slate-400" /> {fornecedor.telefone}
            </p>
            <p className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
              <Truck className="h-4 w-4 text-slate-400" /> Prazo: {fornecedor.prazoEntrega} dias
            </p>
            <p className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
              <Star className="h-4 w-4 text-amber-400" /> {fornecedor.avaliacao.toFixed(1)}
            </p>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Métricas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-slate-500">Total comprado</p>
                <p className="mt-1 text-2xl font-semibold text-slate-800 dark:text-slate-100">{BRL(totalComprado)}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Pedidos recebidos</p>
                <p className="mt-1 text-2xl font-semibold text-slate-800 dark:text-slate-100">{recebidos}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Produtos fornecidos</p>
                <p className="mt-1 text-2xl font-semibold text-slate-800 dark:text-slate-100">{fornecidos.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Produtos fornecidos */}
      <Card>
        <CardHeader>
          <CardTitle>Produtos fornecidos</CardTitle>
        </CardHeader>
        {fornecidos.length === 0 ? (
          <EmptyState title="Sem produtos" description="Este fornecedor não abastece nenhum produto ainda." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wider text-slate-500 dark:border-slate-800">
                  <th className="px-5 py-3 font-medium">Produto</th>
                  <th className="px-5 py-3 font-medium">SKU</th>
                  <th className="px-5 py-3 text-right font-medium">Estoque</th>
                  <th className="px-5 py-3 text-right font-medium">Mínimo</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {fornecidos.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-5 py-3 font-medium text-slate-800 dark:text-slate-100">{p.nome}</td>
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{p.sku}</td>
                    <td className="px-5 py-3 text-right text-slate-700 dark:text-slate-200">{p.estoque}</td>
                    <td className="px-5 py-3 text-right text-slate-700 dark:text-slate-200">{p.minimo}</td>
                    <td className="px-5 py-3"><Badge variant={PRODUTO_STATUS[p.status]}>{p.status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Histórico de compras */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de compras</CardTitle>
        </CardHeader>
        {historico.length === 0 ? (
          <EmptyState title="Sem compras" description="Nenhuma ordem de compra para este fornecedor ainda." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wider text-slate-500 dark:border-slate-800">
                  <th className="px-5 py-3 font-medium">Ordem</th>
                  <th className="px-5 py-3 font-medium">Data</th>
                  <th className="px-5 py-3 text-right font-medium">Total</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {historico.map(o => (
                  <tr key={o.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{o.id}</td>
                    <td className="px-5 py-3 text-slate-600 dark:text-slate-300">{o.data}</td>
                    <td className="px-5 py-3 text-right font-medium text-slate-800 dark:text-slate-100">{BRL(o.total)}</td>
                    <td className="px-5 py-3"><Badge variant={STATUS[o.status]}>{STATUS_LABEL[o.status]}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
