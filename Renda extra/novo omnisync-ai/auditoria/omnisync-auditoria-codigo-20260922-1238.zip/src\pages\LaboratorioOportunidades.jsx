import { useRef, useState } from 'react';
import { oportunidades } from '../data/mockData';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import { useToast } from '../hooks/useToast';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Sparkles } from 'lucide-react';

// ============================================
// Laboratório de Oportunidades — sugestões de
// produtos com alto potencial (geradas por IA).
// ============================================

function ScoreRing({ score, color }) {
  const r = 22;
  const circ = 2 * Math.PI * r;
  const dash = (Math.min(score, 100) / 100) * circ;
  return (
    <div className="relative h-14 w-14 shrink-0">
      <svg viewBox="0 0 56 56" className="h-14 w-14 -rotate-90">
        <circle cx="28" cy="28" r={r} fill="none" strokeWidth="5" className="stroke-slate-200 dark:stroke-slate-700" />
        <circle cx="28" cy="28" r={r} fill="none" strokeWidth="5" strokeLinecap="round" stroke={color} strokeDasharray={`${dash} ${circ}`} />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-sm font-bold text-slate-800 dark:text-slate-100">{score}</span>
    </div>
  );
}

export function LaboratorioOportunidades() {
  const { primaryColor } = useApp();
  const toast = useToast();
  const [importando, setImportando] = useState(null);
  const [categoria, setCategoria] = useState('Todas');
  const [ordem, setOrdem] = useState('score');
  const [ultimaVarredura, setUltimaVarredura] = useState(null);
  const [detalhe, setDetalhe] = useState(null);

  const categorias = ['Todas', ...new Set(oportunidades.map(o => o.categoria))];

  const visiveis = oportunidades
    .filter(o => (categoria === 'Todas' ? true : o.categoria === categoria))
    .sort((a, b) => (ordem === 'potencial' ? b.potencial - a.potencial : b.score - a.score));

  const varrerAgora = () => {
    setUltimaVarredura(new Date().toLocaleString('pt-BR'));
    toast('Varredura do agente concluída');
  };
  // Contador sequencial de importações (evita colisão de SKU sem relógio).
  const seqImportacao = useRef(0);

  const cor = score => (score >= 80 ? '#10b981' : score >= 75 ? primaryColor : '#f59e0b');

  // Importação direta: cadastra a oportunidade como produto via POST /api/produtos.
  const importarParaBase = async o => {
    setImportando(o.id);
    try {
      seqImportacao.current += 1;
      const sku = `LAB-${String(o.id).padStart(3, '0')}-${String(seqImportacao.current).padStart(4, '0')}`;
      await api.criarProduto({
        nome: o.nome,
        sku,
        categoria: o.categoria,
        preco: 0,
        estoque: 0,
        minimo: 0,
        status: 'ativo',
        fornecedor: '',
      });
      toast(`"${o.nome}" adicionado à base de produtos`);
      api.emitirEvento('opportunity.detected', { oportunidade: o.nome, origem: 'laboratorio' }, 'MarketRadar').catch(() => {});
    } catch (e) {
      console.error('Erro ao importar oportunidade:', e);
      toast('Erro ao importar oportunidade');
    } finally {
      setImportando(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-800 dark:text-slate-100">Laboratório de Oportunidades</h1>
          <p className="text-sm text-slate-500">Sugestões de produtos com alto potencial de crescimento</p>
        </div>
        <Button onClick={varrerAgora}>
          <Sparkles className="h-4 w-4" /> Analisar mercado
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {categorias.map(c => (
          <button
            key={c}
            type="button"
            onClick={() => setCategoria(c)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${categoria === c ? 'bg-primary-600 text-white' : 'border border-slate-200 text-slate-600 hover:border-primary-500 hover:text-primary-600 dark:border-slate-700 dark:text-slate-300'}`}
          >
            {c}
          </button>
        ))}
        <select
          value={ordem}
          onChange={e => setOrdem(e.target.value)}
          aria-label="Ordenar por"
          className="h-9 rounded-lg border border-slate-200 bg-white px-3 text-xs text-slate-700 outline-none focus:border-primary-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
        >
          <option value="score">Maior score</option>
          <option value="potencial">Maior potencial (R$/mês)</option>
        </select>
        <span className="ml-auto rounded-full bg-slate-100 px-3 py-1.5 text-xs text-slate-500 dark:bg-slate-800">
          Última varredura: {ultimaVarredura ?? 'sob demanda'}
        </span>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {visiveis.map(o => (
          <Card key={o.id}>
            <div className="flex items-start justify-between gap-3 p-5 pb-0">
              <div className="min-w-0">
                <p className="font-medium text-slate-800 dark:text-slate-100">{o.nome}</p>
                <Badge variant="slate" className="mt-1">{o.categoria}</Badge>
              </div>
              <ScoreRing score={o.score} color={cor(o.score)} />
            </div>
            <button
              type="button"
              onClick={() => setDetalhe(o)}
              className="block w-full p-5 pt-3 text-left"
              title="Abrir detalhamento"
            >
              <p className="text-sm text-slate-500">{o.motivo}</p>
              <p className="mt-3 text-sm">
                <span className="text-slate-400">Potencial estimado: </span>
                <span className="font-semibold text-primary-600 dark:text-primary-400">
                  R$ {o.potencial.toLocaleString('pt-BR')}/mês
                </span>
              </p>
              <span className="mt-1 block text-xs text-primary-600 hover:underline">Ver detalhamento</span>
            </button>
            <div className="px-5 pb-5">
              <Button
                variant="secondary"
                onClick={() => importarParaBase(o)}
                disabled={importando === o.id}
                className="w-full"
              >
                {importando === o.id ? 'Importando...' : 'Adicionar à Base'}
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {detalhe && (
        <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Detalhe da oportunidade">
          <button type="button" aria-label="Fechar" onClick={() => setDetalhe(null)} className="absolute inset-0 bg-slate-900/40" />
          <aside className="absolute right-0 top-0 flex h-full w-full max-w-sm flex-col bg-white shadow-2xl dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 p-5 dark:border-slate-800">
              <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{detalhe.nome}</h2>
              <button type="button" onClick={() => setDetalhe(null)} aria-label="Fechar detalhe" className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800">
                ✕
              </button>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto p-5 text-sm">
              {[
                { label: 'Categoria', valor: detalhe.categoria },
                { label: 'Score', valor: `${detalhe.score}/100` },
                { label: 'Potencial', valor: `R$ ${Number(detalhe.potencial).toLocaleString('pt-BR')}/mês` },
                { label: 'Motivo', valor: detalhe.motivo },
                { label: 'Fornecedores', valor: 'Sugestões via Radar de Mercado e Fornecedores' },
                { label: 'Concorrência', valor: 'Avaliar na aba Mercado da Inteligência do Produto' },
              ].map(l => (
                <div key={l.label} className="flex items-center justify-between gap-4 border-b border-slate-100 pb-2 dark:border-slate-800">
                  <span className="text-slate-500">{l.label}</span>
                  <span className="text-right font-medium text-slate-800 dark:text-slate-100">{l.valor}</span>
                </div>
              ))}
              <Button onClick={() => { importarParaBase(detalhe); }} disabled={importando === detalhe.id} className="w-full">
                {importando === detalhe.id ? 'Importando...' : 'Adicionar à Base'}
              </Button>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
