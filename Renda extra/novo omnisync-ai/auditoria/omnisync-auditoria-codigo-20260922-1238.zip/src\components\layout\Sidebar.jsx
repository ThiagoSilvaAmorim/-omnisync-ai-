import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { FlaskConical, LogOut, Infinity as InfinityIcon, Zap } from 'lucide-react';
import { cn } from '../../lib/utils';
import { useAuth } from '../../context/AuthContext';
import { SECTIONS as NAV_SECTIONS } from '../../lib/navigation';

// ============================================
// Sidebar — menu de navegação agrupado por seção.
// O fundo e o item ativo mudam conforme o tema.
// ============================================

export function Sidebar({ onNavigate }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Componente para ícone com destaque especial (Central de IA: fundo verde claro).
  const ItemIcone = ({ Icone, destaque }) => (
    <span className={cn(
      'h-4 w-4 shrink-0 flex items-center justify-center'
    )}>
      {destaque ? <Zap className="h-4 w-4" /> : <Icone className="h-4 w-4" />}
    </span>
  );

  return (
    <div className="flex h-full flex-col" style={{ background: 'var(--tl-sidebar-bg)' }}>
      {/* Logo */}
      <div className="flex h-16 shrink-0 items-center gap-2.5 px-5">
        <span className="flex h-9 w-9 items-center justify-center bg-primary-600 [border-radius:var(--tl-radius-sm)]">
          <InfinityIcon className="h-5 w-5 text-white" />
        </span>
        <span className="text-base font-bold text-white">OmniSync AI</span>
      </div>

      {/* Navegação */}
      <nav className="flex-1 space-y-5 overflow-y-auto py-4 pl-3 pr-0">
        <div className="pr-3">
          {/* Removido toggle "Testar novo menu (6 itens)" - menu simplificado para produção */}
        </div>
        {NAV_SECTIONS.map(secao => (
          <div key={secao.titulo}>
            <p className="px-3 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              {secao.titulo}
            </p>
            <ul className="space-y-0.5">
              {secao.itens.map(item => (
                <li key={item.nome}>
                  <NavLink
                    to={item.rota}
                    onClick={onNavigate}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-3 rounded-l-xl px-3 py-2 text-sm transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-400',
                        isActive
                          ? '-mr-3 font-medium text-slate-900 shadow-[4px_0_12px_rgba(0,0,0,0.15)]'
                          : 'text-slate-200 hover:bg-white/5 hover:text-white',
                        item.destaque && 'bg-emerald-500/10 hover:bg-emerald-500/20'
                      )
                    }
                    style={({ isActive }) =>
                      isActive ? { background: 'var(--tl-sidebar-active)' } : undefined
                    }
                  >
                    <ItemIcone Icone={item.Icone} destaque={item.destaque} />
                    <span className={cn('truncate', item.destaque && 'font-semibold text-emerald-300')}>
                      {item.nome}
                    </span>
                    {item.destaque && (
                      <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-slate-900 text-[10px] font-bold animate-pulse">
                        ★
                      </span>
                    )}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      {/* Usuário no rodapé */}
      <div className="shrink-0 border-t border-white/10 p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center bg-gradient-to-br from-primary-500 to-primary-700 text-sm font-semibold text-white [border-radius:var(--tl-radius-sm)]">
            {user?.nome?.charAt(0) || 'U'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-white">{user?.nome || 'Usuário'}</p>
            <p className="truncate text-xs text-slate-400">{user?.email || 'Administrador'}</p>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-white/10 hover:text-white"
            title="Sair"
            aria-label="Sair"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
