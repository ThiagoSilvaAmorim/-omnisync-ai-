import { useEffect, useState } from 'react';
import { ArrowUpRight, FolderDown, Plug, RefreshCw } from 'lucide-react';
import { integracoes } from '../data/mockData';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import { useToast } from '../hooks/useToast';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';

// ============================================
// Integrações — conexão via página oficial
// (fluxo OAuth): redireciona para a página do
// marketplace/rede social e confirma a autorização.
// ============================================

// Cartão do Google Drive: status real do backend + passo a passo honesto.
function DriveCard() {
  const [status, setStatus] = useState(null);
  useEffect(() => {
    api.statusDrive().then(setStatus).catch(() => setStatus({ vinculado: false }));
  }, []);
  return (
    <Card>
      <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-50 text-primary-600 dark:bg-primary-500/10 dark:text-primary-400">
            <FolderDown className="h-5 w-5" />
          </span>
          <div>
            <p className="font-medium text-slate-800 dark:text-slate-100">Google Drive</p>
            <p className="text-xs text-slate-500">
              {status == null ? 'Verificando vínculo...' : status.vinculado
                ? `Vinculado (${status.via})${status.pasta ? ` • pasta ${status.pasta}` : ''}`
                : 'Não vinculado — pacotes e relatórios baixam localmente'}
            </p>
          </div>
        </div>
        <Badge variant={status?.vinculado ? 'teal' : 'slate'}>{status?.vinculado ? 'Vinculado' : 'Desvinculado'}</Badge>
      </div>
      {status && !status.vinculado && status.comoVincular && (
        <div className="space-y-1 px-5 pb-5 text-xs text-slate-500">
          {status.comoVincular.map((passo, i) => <p key={i}>{passo}</p>)}
        </div>
      )}
    </Card>
  );
}

export function Integracoes() {
  const toast = useToast();
  const { addNotificacao } = useApp();
  const [estado, setEstado] = useState(() => Object.fromEntries(integracoes.map(i => [i.id, i.status])));
  const [sincronizando, setSincronizando] = useState(null);
  const [busca, setBusca] = useState('');
  const [categoria, setCategoria] = useState('Todas');

  const categorias = ['Todas', ...new Set(integracoes.map(i => i.categoria))];
  const visiveis = integracoes.filter(i => {
    if (busca && !`${i.nome} ${i.descricao}`.toLowerCase().includes(busca.toLowerCase())) return false;
    if (categoria !== 'Todas' && i.categoria !== categoria) return false;
    return true;
  });

  // Fluxo de conexão OAuth
  const [conectando, setConectando] = useState(null);
  const [redirecionado, setRedirecionado] = useState(false);

  const abrirConexao = i => {
    setConectando(i);
    setRedirecionado(false);
  };

  const irParaOficial = () => {
    if (conectando?.authUrl) {
      window.open(conectando.authUrl, '_blank', 'noopener,noreferrer');
    }
    setRedirecionado(true);
  };

  const confirmarConexao = () => {
    setEstado(prev => ({ ...prev, [conectando.id]: 'conectado' }));
    toast(`Integração ${conectando.nome} conectada com sucesso`);
    addNotificacao(`Integração ${conectando.nome} conectada`, 'Autorização concedida na página oficial.');
    setConectando(null);
    setRedirecionado(false);
  };

  const toggle = i => {
    setEstado(prev => ({ ...prev, [i.id]: prev[i.id] === 'conectado' ? 'desconectado' : 'conectado' }));
    toast(`Integração ${i.nome} ${estado[i.id] === 'conectado' ? 'desconectada' : 'conectada'}`);
  };

  const sync = async i => {
    setSincronizando(i.id);
    try {
      const r = await api.syncMarketplace(i.id);
      const msg = `${r.novosPedidos ?? 0} pedidos importados, ${r.comprasGeradas ?? 0} ordem(ns) de compra automática(s)`;
      toast(`Sincronização: ${msg}`);
      addNotificacao(`Sincronização com ${i.nome}`, msg);
    } catch (err) {
      toast(`Erro ao sincronizar: ${err.message}`);
    } finally {
      setSincronizando(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-800 dark:text-slate-100">Integrações</h1>
        <p className="text-sm text-slate-500">
          Conecte suas contas autorizando na página oficial de cada serviço
        </p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <input
          type="text"
          value={busca}
          onChange={e => setBusca(e.target.value)}
          placeholder="Buscar integração..."
          className="h-10 w-full rounded-lg border border-slate-200 bg-white px-4 text-sm text-slate-700 outline-none focus:border-primary-500 sm:max-w-xs dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
        />
        <div className="flex flex-wrap gap-2">
          {categorias.map(c => (
            <button
              key={c}
              type="button"
              onClick={() => setCategoria(c)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${categoria === c ? 'bg-primary-600 text-white' : 'border border-slate-200 text-slate-600 hover:border-primary-500 hover:text-primary-600 dark:border-slate-700 dark:text-slate-300'}`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <p className="text-xs text-slate-400">Multi-instância (várias contas da mesma plataforma) segue BLOCKED até tabela de contas + OAuth no Neon.</p>

      <DriveCard />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {visiveis.map(i => {
          const conectado = estado[i.id] === 'conectado';
          const isMarketplace = i.categoria === 'Marketplace';
          return (
            <Card key={i.id}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-50 text-primary-600 dark:bg-primary-500/10 dark:text-primary-400">
                    <Plug className="h-5 w-5" />
                  </span>
                  <div>
                    <CardTitle>{i.nome}</CardTitle>
                    <p className="text-xs text-slate-500">{i.categoria}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-500">{i.descricao}</p>
                <div className="mt-4 flex items-center justify-between">
                  <Badge variant={conectado ? 'teal' : 'slate'}>
                    {conectado ? 'Conectado' : 'Desconectado'}
                  </Badge>
                  <Button
                    size="sm"
                    variant={conectado ? 'secondary' : 'primary'}
                    onClick={() => (conectado ? toggle(i) : abrirConexao(i))}
                  >
                    {conectado ? 'Desconectar' : 'Conectar'}
                  </Button>
                </div>
                {isMarketplace && conectado && (
                  <Button size="sm" variant="secondary" className="mt-2 w-full" onClick={() => sync(i)} disabled={sincronizando === i.id}>
                    <RefreshCw className={`h-4 w-4 ${sincronizando === i.id ? 'animate-spin' : ''}`} />
                    {sincronizando === i.id ? 'Sincronizando...' : 'Sincronizar agora'}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Modal de conexão (fluxo OAuth) */}
      <Modal open={!!conectando} onClose={() => setConectando(null)} title={`Conectar ${conectando?.nome ?? ''}`}>
        <div className="space-y-4">
          <p className="text-sm text-slate-500">
            Você será redirecionado para a <strong>página oficial do {conectando?.nome}</strong> para
            dar permissão de acesso à sua conta.
          </p>

          <div className="rounded-lg bg-slate-50 p-3 text-xs text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            <p><strong>Passo 1:</strong> clique em "Continuar" e faça login na página oficial.</p>
            <p><strong>Passo 2:</strong> autorize o OmniSync AI a acessar sua conta.</p>
            <p><strong>Passo 3:</strong> volte aqui e clique em "Já autorizei".</p>
          </div>

          {!redirecionado ? (
            <Button className="w-full" onClick={irParaOficial}>
              <ArrowUpRight className="h-4 w-4" /> Continuar para {conectando?.nome}
            </Button>
          ) : (
            <div className="space-y-2">
              <p className="flex items-center gap-1.5 text-xs text-teal-600 dark:text-teal-400">
                ✓ Página oficial aberta em nova aba
              </p>
              <Button className="w-full" onClick={confirmarConexao}>
                Já autorizei — concluir conexão
              </Button>
              <Button variant="secondary" className="w-full" onClick={irParaOficial}>
                Abrir a página novamente
              </Button>
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}
