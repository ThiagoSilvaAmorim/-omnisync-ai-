import { useState } from 'react';
import { Plus, Sparkles, Truck, X } from 'lucide-react';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { produtos } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { useToast } from '../hooks/useToast';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';

// ============================================
// Compras — ordens de compra com ciclo de
// acompanhamento (pendente → enviado → em trânsito
// → recebido) + reposição automática.
// ============================================

const STATUS = { pendente: 'slate', enviado: 'sky', 'em trânsito': 'amber', recebido: 'teal' };
const STATUS_LABEL = { pendente: 'Pendente', enviado: 'Enviado', 'em trânsito': 'Em trânsito', recebido: 'Recebido' };
const FLUXO = ['pendente', 'enviado', 'em trânsito', 'recebido'];

// Contador para gerar ids de ordens de compra (mock).
let contadorOC = 1000;

// Data de hoje calculada uma única vez (fora do render).
const HOJE = new Date().toLocaleDateString('pt-BR');

export function Compras() {
  const toast = useToast();
  const { ordens, criarOrdem, avancarOrdem } = useApp();

  const [busca, setBusca] = useState('');
  const [statusFiltro, setStatusFiltro] = useState('todas');
  const [rastreio, setRastreio] = useState(null);
  const [modalNova, setModalNova] = useState(false);
  const [formCompra, setFormCompra] = useState({ fornecedor: '', total: '' });

  const salvarCompra = () => {
    if (!formCompra.fornecedor.trim() || !(Number(formCompra.total) > 0)) {
      toast('Preencha fornecedor e um total válido');
      return;
    }
    criarOrdem({
      id: `OC-${++contadorOC}`,
      fornecedor: formCompra.fornecedor.trim(),
      data: HOJE,
      total: Math.round(Number(formCompra.total) * 100) / 100,
      status: 'pendente',
      origem: 'manual',
    });
    setFormCompra({ fornecedor: '', total: '' });
    setModalNova(false);
    toast('Ordem de compra criada');
  };

  // Produtos que precisam de reposição (estoque <= mínimo).
  const reposicao = produtos.filter(p => p.estoque <= p.minimo);

  const ordensFiltradas = ordens.filter(o => {
    if (busca && !`${o.id} ${o.fornecedor}`.toLowerCase().includes(busca.toLowerCase())) return false;
    if (statusFiltro !== 'todas' && o.status !== statusFiltro) return false;
    return true;
  });

  const pedirTodos = () => {
    if (reposicao.length === 0) {
      toast('Nenhum item crítico para pedir');
      return;
    }
    reposicao.forEach(p => gerarCompra(p));
    toast(`${reposicao.length} pedido(s) de compra enviados`);
  };

  const gerarCompra = p => {
    const quantidade = Math.max(p.minimo * 2 - p.estoque, 10);
    criarOrdem({
      id: `OC-${++contadorOC}`,
      fornecedor: p.fornecedor,
      data: HOJE,
      total: Math.round(p.preco * quantidade * 100) / 100,
      status: 'pendente',
      origem: 'automática',
    });
    toast(`Pedido de compra automático enviado a ${p.fornecedor}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-800 dark:text-slate-100">Compras</h1>
          <p className="text-sm text-slate-500">Ordens de compra, fornecedores e reposição automática</p>
        </div>
        <Button onClick={() => setModalNova(true)}>
          <Plus className="h-4 w-4" /> Nova compra
        </Button>
      </div>

      <Modal open={modalNova} onClose={() => setModalNova(false)} title="Nova ordem de compra">
        <div className="space-y-3">
          <Input label="Fornecedor *" value={formCompra.fornecedor} onChange={e => setFormCompra(f => ({ ...f, fornecedor: e.target.value }))} placeholder="Ex: Leo Madeiras" />
          <Input label="Total (R$) *" type="number" min="0" value={formCompra.total} onChange={e => setFormCompra(f => ({ ...f, total: e.target.value }))} />
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setModalNova(false)}>
            Cancelar
          </Button>
          <Button onClick={salvarCompra}>
            Criar ordem
          </Button>
        </div>
      </Modal>

      {/* Reposição automática */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary-500" />
            <CardTitle>Reposição automática</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={reposicao.length > 0 ? 'amber' : 'teal'}>
              {reposicao.length} abaixo do mínimo
            </Badge>
            {reposicao.length > 0 && (
              <Button size="sm" onClick={pedirTodos}>
                <Truck className="h-4 w-4" /> Pedir todos
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {reposicao.length === 0 ? (
            <p className="text-sm text-slate-500">Todos os produtos estão com estoque saudável. 🎉</p>
          ) : (
            <div className="space-y-3">
              {reposicao.map(p => (
                <div
                  key={p.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 p-4 dark:border-slate-800"
                >
                  <div className="min-w-0">
                    <p className="font-medium text-slate-800 dark:text-slate-100">{p.nome}</p>
                    <p className="text-xs text-slate-500">
                      Estoque atual: {p.estoque} · Mínimo: {p.minimo} · Fornecedor: {p.fornecedor}
                    </p>
                  </div>
                  <Button size="sm" onClick={() => gerarCompra(p)}>
                    <Truck className="h-4 w-4" /> Pedir ao fornecedor
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Ordens de compra com ciclo */}
      <Card>
        <CardHeader>
          <CardTitle>Ordens de compra</CardTitle>
          <div className="flex flex-wrap gap-2">
            <input
              type="text"
              value={busca}
              onChange={e => setBusca(e.target.value)}
              placeholder="Buscar ordem ou fornecedor..."
              className="h-9 w-56 rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 outline-none focus:border-primary-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            />
            <select
              value={statusFiltro}
              onChange={e => setStatusFiltro(e.target.value)}
              aria-label="Filtrar por status"
              className="h-9 rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 outline-none focus:border-primary-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              {['todas', ...FLUXO].map(s => (
                <option key={s} value={s}>{s === 'todas' ? 'Todos os status' : STATUS_LABEL[s]}</option>
              ))}
            </select>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wider text-slate-500 dark:border-slate-800">
                <th className="px-5 py-3 font-medium">Ordem</th>
                <th className="px-5 py-3 font-medium">Fornecedor</th>
                <th className="px-5 py-3 font-medium">Data</th>
                <th className="px-5 py-3 text-right font-medium">Total</th>
                <th className="px-5 py-3 font-medium">Ciclo</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {ordensFiltradas.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-6 text-center text-sm text-slate-500">
                    Nenhuma ordem encontrada.
                  </td>
                </tr>
              ) : (
                ordensFiltradas.map(c => {
                  const etapaAtual = FLUXO.indexOf(c.status);
                  return (
                    <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="px-5 py-3">
                        <button
                          type="button"
                          onClick={() => setRastreio(c)}
                          title="Abrir histórico de rastreio"
                          className="font-mono text-xs text-primary-600 hover:underline"
                        >
                          {c.id}
                        </button>
                      </td>
                      <td className="px-5 py-3 font-medium text-slate-800 dark:text-slate-100">{c.fornecedor}</td>
                      <td className="px-5 py-3 text-slate-600 dark:text-slate-300">{c.data}</td>
                      <td className="px-5 py-3 text-right font-medium text-slate-800 dark:text-slate-100">
                        R$ {Number(c.total).toFixed(2).replace('.', ',')}
                      </td>
                      <td className="px-5 py-3">
                        <div
                          className="flex items-center gap-1"
                          title={`Ciclo: ${FLUXO.map(f => `${f === c.status ? '● ' : '○ '}${STATUS_LABEL[f]}`).join(' → ')}`}
                        >
                          {FLUXO.map((f, i) => (
                            <span
                              key={f}
                              title={STATUS_LABEL[f]}
                              className={`h-1.5 w-5 rounded-full ${
                                i <= etapaAtual ? 'bg-primary-500' : 'bg-slate-200 dark:bg-slate-700'
                              }`}
                            />
                          ))}
                        </div>
                      </td>
                      <td className="px-5 py-3"><Badge variant={STATUS[c.status]}>{STATUS_LABEL[c.status]}</Badge></td>
                      <td className="px-5 py-3">
                        {c.status !== 'recebido' ? (
                          <Button size="sm" variant="secondary" onClick={() => avancarOrdem(c.id)}>
                            Avançar
                          </Button>
                        ) : (
                          <span className="text-xs text-teal-600 dark:text-teal-400">Concluído ✓</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {rastreio && (
        <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={`Rastreio ${rastreio.id}`}>
          <button type="button" aria-label="Fechar" onClick={() => setRastreio(null)} className="absolute inset-0 bg-slate-900/40" />
          <aside className="absolute right-0 top-0 flex h-full w-full max-w-sm flex-col bg-white shadow-2xl dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 p-5 dark:border-slate-800">
              <h2 className="font-mono text-lg font-semibold text-slate-800 dark:text-slate-100">{rastreio.id}</h2>
              <button type="button" onClick={() => setRastreio(null)} aria-label="Fechar rastreio" className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 space-y-4 overflow-y-auto p-5">
              <div className="text-sm">
                <p className="text-slate-500">Fornecedor</p>
                <p className="font-medium text-slate-800 dark:text-slate-100">{rastreio.fornecedor}</p>
              </div>
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Histórico do ciclo</p>
                <ol className="space-y-3 border-l-2 border-slate-200 pl-4 dark:border-slate-700">
                  {FLUXO.map(f => {
                    const concluida = FLUXO.indexOf(f) <= FLUXO.indexOf(rastreio.status);
                    return (
                      <li key={f} className="relative text-sm">
                        <span className={`absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full ${concluida ? 'bg-primary-500' : 'bg-slate-300 dark:bg-slate-600'}`} />
                        <p className={`font-medium ${concluida ? 'text-slate-800 dark:text-slate-100' : 'text-slate-400'}`}>{STATUS_LABEL[f]}</p>
                        {f === rastreio.status && <p className="text-xs text-primary-600">Etapa atual</p>}
                      </li>
                    );
                  })}
                </ol>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-800">
                <p className="text-slate-500">Total</p>
                <p className="font-semibold text-slate-800 dark:text-slate-100">R$ {Number(rastreio.total).toFixed(2).replace('.', ',')}</p>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
